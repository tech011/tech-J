package stroperation;
public class com{

public void compare(String s1, String s2){
    if(s1.equals(s2)){
        System.out.println("Strings are equal");
    }
    else{
        System.out.println("Strings are not equal");
    }
}
}