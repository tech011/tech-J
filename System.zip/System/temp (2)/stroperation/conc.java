package stroperation;
public class conc{
 public void concate(String s1,String s2){
    String result = s1 + s2;
    System.out.println("Conate string is "+result);
 }
}